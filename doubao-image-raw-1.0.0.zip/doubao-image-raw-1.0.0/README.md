# doubao-image-raw
